#!/usr/bin/python
# -*- coding: UTF-8 -*-
# vim:set shiftwidth=4 tabstop=4 expandtab textwidth=79:

import sys
import os
import awn
import gtk
import gobject
from subprocess import Popen

os.environ['UBUNTU_MENUPROXY'] = ''

def plug(sid):
    print 'Indicator3.window: %s' % sid
    Popen(['/usr/lib/awn/applets/appmenu/appmenu-helper', str(sid)])

def fixsize(sid):
    win = gtk.gdk.window_foreign_new(sid)
    def do(win, i = True):
        x, y, w, h, d = win.get_geometry()
        cx, cy = win.get_deskrelative_origin()
        if cy > 100:
            win.move(x, h/2)
            pass
        else:
            win.move(x, 0)
            r = gtk.gdk.Region()
            r.union_with_rect(gtk.gdk.Rectangle(0, 0, w, h/2 + 5))
            win.shape_combine_region(r, 0, 0)
            pass
        return i == True or i and i.pop()
    #gobject.timeout_add(100, do, win, [1]*35)
    gobject.timeout_add(100, do, win)
    pass

def main():
    awn.init(sys.argv[1:])
    sid = awn.window
    gobject.timeout_add(1, plug, sid)
    fixsize(sid)
    gobject.timeout_add(10, fixsize, sid)
    gtk.main()

if __name__ == "__main__":
    main()
